import Footer from "../../components/footer/footer";
import Header from "../../components/header/header";
function Events() {
    return (
        <>
            <Header />
            <Footer />
        </>
    );
}

export default Events;
