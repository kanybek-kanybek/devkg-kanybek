import Footer from "../../components/footer/footer";
import Header from "../../components/header/header";

function JobOpenings() {
    return (
        <>
            <Header />
            <Footer />
        </>
    );
}

export default JobOpenings;
